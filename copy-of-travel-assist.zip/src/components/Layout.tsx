import { Link, Outlet } from 'react-router-dom';
import { Plane, Phone, MessageCircle, Search } from 'lucide-react';
import { motion } from 'motion/react';

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900">
      <header className="bg-white text-slate-900 sticky top-0 z-50 py-3 shadow-sm border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="relative w-14 h-14 bg-blue-900 rounded-2xl flex items-center justify-center shadow-lg transform group-hover:rotate-6 transition-transform">
                <Plane className="w-8 h-8 text-white" />
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white"></div>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-black text-blue-900 leading-none tracking-tight uppercase">Travel Assist</span>
              </div>
            </Link>
            
            <div className="flex items-center space-x-4">
              <nav className="hidden lg:flex items-center space-x-6 mr-4">
                <Link to="/" className="text-sm font-bold text-slate-600 hover:text-blue-600 transition-colors uppercase tracking-wider">Home</Link>
              </nav>

              <div className="flex items-center space-x-2">
                <a href="https://wa.me/918582942118" target="_blank" rel="noopener noreferrer" className="flex items-center bg-emerald-500 text-white rounded-lg p-2 hover:bg-emerald-600 transition-colors shadow-md shadow-emerald-100">
                  <MessageCircle className="w-5 h-5" />
                  <span className="hidden sm:inline-block ml-2 text-xs font-bold uppercase">WhatsApp</span>
                </a>
                
                <a href="tel:+918582942118" className="hidden md:flex items-center bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 hover:bg-slate-100 transition-colors">
                  <div className="bg-blue-600 p-2 rounded-lg mr-3 shadow-md shadow-blue-200">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-bold leading-none mb-1">Contact Booking Expert</div>
                    <div className="text-lg font-black text-slate-900 leading-none">+91 8582942118</div>
                  </div>
                </a>
              </div>
              
              <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors md:hidden">
                <div className="w-6 h-0.5 bg-slate-900 mb-1.5"></div>
                <div className="w-6 h-0.5 bg-slate-900 mb-1.5"></div>
                <div className="w-6 h-0.5 bg-slate-900"></div>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Floating WhatsApp Button */}
      <motion.a
        href="https://wa.me/918582942118"
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        className="fixed bottom-8 right-8 z-50 bg-emerald-500 text-white p-4 rounded-full shadow-2xl flex items-center justify-center"
      >
        <MessageCircle className="w-8 h-8" />
      </motion.a>

      {/* Footer */}
      <footer className="bg-[#1a2b48] text-slate-300 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center space-x-3 mb-6">
                 <div className="relative w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                  <Plane className="w-8 h-8 text-blue-900" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-black text-white leading-none tracking-tight uppercase">Travel Assist</span>
                </div>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                Independent travel assistance service helping customers search, compare, and book flight tickets worldwide.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Quick Links</h3>
              <ul className="space-y-3 text-sm">
                <li><Link to="/" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Search Flights</Link></li>
                <li><Link to="/get-quote" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Get a Quote</Link></li>
                <li><Link to="/contact" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Contact Us</Link></li>
                <li><Link to="/aviation-data" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Aviation Database</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Legal & Policies</h3>
              <ul className="space-y-3 text-sm">
                <li><Link to="/policies" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Terms & Conditions</Link></li>
                <li><Link to="/policies" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Privacy Policy</Link></li>
                <li><Link to="/policies" className="hover:text-white transition-colors flex items-center"><span className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></span> Refund Policy</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-6 uppercase tracking-wider text-sm">Contact Support</h3>
              <ul className="space-y-4 text-sm">
                <li className="flex items-start">
                  <Phone className="w-5 h-5 mr-3 text-blue-400 shrink-0" />
                  <div>
                    <div className="text-xs text-slate-500 uppercase font-bold mb-1">Phone / WhatsApp</div>
                    <div className="text-white font-bold">+91 8582942118</div>
                  </div>
                </li>
                <li className="flex items-start">
                  <MessageCircle className="w-5 h-5 mr-3 text-blue-400 shrink-0" />
                  <div>
                    <div className="text-xs text-slate-500 uppercase font-bold mb-1">Email Support</div>
                    <div className="text-white font-bold break-all">travelassisthelp1@gmail.com</div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-12 pt-8 text-xs text-center text-slate-500">
            <p className="max-w-3xl mx-auto mb-4 leading-relaxed">Travel Assist is an independent travel support provider. We help customers check flight schedules, availability, and prices. All flight schedules and fares displayed on this website are indicative and subject to change without prior notice. Tickets are issued only after full payment confirmation. We are not directly affiliated with any airline. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
