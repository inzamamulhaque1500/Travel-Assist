import React, { useState, useRef, useEffect } from 'react';
import { PlaneTakeoff, PlaneLanding } from 'lucide-react';

import { AIRPORTS } from '../data/airports';

export default function AirportInput({ value, onChange, placeholder, type }: { value: string, onChange: (v: string) => void, placeholder: string, type: 'from' | 'to' }) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState(value);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSearch(value);
  }, [value]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filtered = AIRPORTS.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.city.toLowerCase().includes(search.toLowerCase()) ||
    (a.state && a.state.toLowerCase().includes(search.toLowerCase())) ||
    a.iata.toLowerCase().includes(search.toLowerCase()) ||
    a.country.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative" ref={wrapperRef}>
      {type === 'from' ? (
        <PlaneTakeoff className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
      ) : (
        <PlaneLanding className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
      )}
      <input 
        type="text" 
        placeholder={placeholder}
        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
        value={search}
        onChange={(e) => {
          setSearch(e.target.value);
          onChange(e.target.value);
          setIsOpen(true);
        }}
        onFocus={() => setIsOpen(true)}
        required
      />
      {isOpen && search && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {filtered.length > 0 ? filtered.map(airport => (
            <div 
              key={airport.iata} 
              className="px-4 py-3 hover:bg-blue-50 cursor-pointer border-b border-slate-100 last:border-0"
              onClick={() => {
                const val = `${airport.city} (${airport.iata})`;
                setSearch(val);
                onChange(val);
                setIsOpen(false);
              }}
            >
              <div className="flex justify-between items-center">
                <span className="font-semibold text-slate-900">{airport.city} {airport.state && <span className="text-slate-500 text-sm font-normal">({airport.state})</span>}</span>
                <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded">{airport.iata}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">{airport.name}</div>
            </div>
          )) : (
            <div className="px-4 py-3 text-sm text-slate-500">No airports found</div>
          )}
        </div>
      )}
    </div>
  );
}
