import React from 'react';

const COUNTRIES = [
  "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo (Republic)", "Congo (Democratic Republic)", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

const FORMATS = [
  "Flights from [Origin] to [Dest]",
  "Cheap flights from [Origin] to [Dest]",
  "Direct flights from [Origin] to [Dest]",
  "Business class flights from [Origin] to [Dest]",
  "First class flights from [Origin] to [Dest]",
  "Last minute flights from [Origin] to [Dest]",
  "Best flight deals from [Origin] to [Dest]"
];

export default function PopularRoutes() {
  // Generate a subset of combinations for display
  const generateKeywords = () => {
    const keywords = [];
    const shuffled = [...COUNTRIES].sort(() => 0.5 - Math.random());
    
    // Create about 100 diverse combinations for the UI
    for (let i = 0; i < 50; i++) {
      const origin = shuffled[i];
      const dest = shuffled[(i + 1) % shuffled.length];
      const format = FORMATS[Math.floor(Math.random() * FORMATS.length)];
      
      keywords.push(format.replace('[Origin]', origin).replace('[Dest]', dest));
    }
    return keywords;
  };

  const keywords = generateKeywords();

  return (
    <section className="py-12 bg-slate-100 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-xl font-bold text-slate-800 mb-8 uppercase tracking-wider border-l-4 border-orange-600 pl-4">
          Popular Global Flight Routes & Search Queries
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-3">
          {keywords.map((kw, idx) => (
            <div key={idx} className="text-slate-500 text-sm hover:text-orange-600 cursor-pointer transition-colors">
              {kw}
            </div>
          ))}
        </div>
        
        <div className="mt-12 pt-8 border-t border-slate-200 text-center">
          <p className="text-slate-400 text-xs max-w-4xl mx-auto leading-relaxed">
            Travel Assist provides global flight search capabilities across all major airlines. Whether you're looking for 
            economy travel or premium luxury experiences, our expert agents help you find the best deals from 
            {COUNTRIES.slice(0, 10).join(', ')} and hundreds of other locations worldwide. 
            Book your next journey with confidence.
          </p>
        </div>
      </div>
    </section>
  );
}
