export interface Airline {
  name: string;
  code: string;
  iata: string;
  icao: string;
  country: string;
  type: 'Full Service' | 'Low Cost' | 'Charter';
  logo: string;
}

export const AIRLINES: Airline[] = [
  { name: 'Emirates', code: 'EK', iata: 'EK', icao: 'UAE', country: 'United Arab Emirates', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/EK.png' },
  { name: 'Qatar Airways', code: 'QR', iata: 'QR', icao: 'QTR', country: 'Qatar', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/QR.png' },
  { name: 'Singapore Airlines', code: 'SQ', iata: 'SQ', icao: 'SIA', country: 'Singapore', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/SQ.png' },
  { name: 'Turkish Airlines', code: 'TK', iata: 'TK', icao: 'THY', country: 'Turkey', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/TK.png' },
  { name: 'Lufthansa', code: 'LH', iata: 'LH', icao: 'DLH', country: 'Germany', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/LH.png' },
  { name: 'Air France', code: 'AF', iata: 'AF', icao: 'AFR', country: 'France', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AF.png' },
  { name: 'British Airways', code: 'BA', iata: 'BA', icao: 'BAW', country: 'United Kingdom', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/BA.png' },
  { name: 'United Airlines', code: 'UA', iata: 'UA', icao: 'UAL', country: 'United States', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/UA.png' },
  { name: 'Delta Air Lines', code: 'DL', iata: 'DL', icao: 'DAL', country: 'United States', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/DL.png' },
  { name: 'American Airlines', code: 'AA', iata: 'AA', icao: 'AAL', country: 'United States', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AA.png' },
  { name: 'Air India', code: 'AI', iata: 'AI', icao: 'AIC', country: 'India', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AI.png' },
  { name: 'IndiGo', code: '6E', iata: '6E', icao: 'IGO', country: 'India', type: 'Low Cost', logo: 'https://www.gstatic.com/flights/airline_logos/70px/6E.png' },
  { name: 'Etihad Airways', code: 'EY', iata: 'EY', icao: 'ETD', country: 'United Arab Emirates', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/EY.png' },
  { name: 'Cathay Pacific', code: 'CX', iata: 'CX', icao: 'CPA', country: 'Hong Kong', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/CX.png' },
  { name: 'Qantas', code: 'QF', iata: 'QF', icao: 'QFA', country: 'Australia', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/QF.png' },
  { name: 'Air Canada', code: 'AC', iata: 'AC', icao: 'ACA', country: 'Canada', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AC.png' },
  { name: 'Swiss International', code: 'LX', iata: 'LX', icao: 'SWR', country: 'Switzerland', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/LX.png' },
  { name: 'KLM Royal Dutch', code: 'KL', iata: 'KL', icao: 'KLM', country: 'Netherlands', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/KL.png' },
  { name: 'Japan Airlines', code: 'JL', iata: 'JL', icao: 'JAL', country: 'Japan', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/JL.png' },
  { name: 'All Nippon Airways', code: 'NH', iata: 'NH', icao: 'ANA', country: 'Japan', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/NH.png' },
  { name: 'Korean Air', code: 'KE', iata: 'KE', icao: 'KAL', country: 'South Korea', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/KE.png' },
  { name: 'Thai Airways', code: 'TG', iata: 'TG', icao: 'THA', country: 'Thailand', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/TG.png' },
  { name: 'Malaysia Airlines', code: 'MH', iata: 'MH', icao: 'MAS', country: 'Malaysia', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/MH.png' },
  { name: 'Virgin Atlantic', code: 'VS', iata: 'VS', icao: 'VIR', country: 'United Kingdom', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/VS.png' },
  { name: 'Vistara', code: 'UK', iata: 'UK', icao: 'VTI', country: 'India', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/UK.png' },
  { name: 'Ethiopian Airlines', code: 'ET', iata: 'ET', icao: 'ETH', country: 'Ethiopia', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/ET.png' },
  { name: 'Kenya Airways', code: 'KQ', iata: 'KQ', icao: 'KQA', country: 'Kenya', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/KQ.png' },
  { name: 'South African Airways', code: 'SA', iata: 'SA', icao: 'SAA', country: 'South Africa', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/SA.png' },
  { name: 'EgyptAir', code: 'MS', iata: 'MS', icao: 'MSR', country: 'Egypt', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/MS.png' },
  { name: 'Royal Air Maroc', code: 'AT', iata: 'AT', icao: 'RAM', country: 'Morocco', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AT.png' },
  { name: 'Aeromexico', code: 'AM', iata: 'AM', icao: 'AMX', country: 'Mexico', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AM.png' },
  { name: 'LATAM Airlines', code: 'LA', iata: 'LA', icao: 'LAN', country: 'Chile', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/LA.png' },
  { name: 'Avianca', code: 'AV', iata: 'AV', icao: 'AVA', country: 'Colombia', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AV.png' },
  { name: 'Aerolineas Argentinas', code: 'AR', iata: 'AR', icao: 'ARG', country: 'Argentina', type: 'Full Service', logo: 'https://www.gstatic.com/flights/airline_logos/70px/AR.png' },
];
