import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import SearchResults from './pages/SearchResults';
import BookingRequest from './pages/BookingRequest';
import BookingConfirmation from './pages/BookingConfirmation';
import GetQuote from './pages/GetQuote';
import Contact from './pages/Contact';
import Policies from './pages/Policies';
import AviationData from './pages/AviationData';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="results" element={<SearchResults />} />
          <Route path="booking-request" element={<BookingRequest />} />
          <Route path="booking-confirmation" element={<BookingConfirmation />} />
          <Route path="get-quote" element={<GetQuote />} />
          <Route path="contact" element={<Contact />} />
          <Route path="policies" element={<Policies />} />
          <Route path="aviation-data" element={<AviationData />} />
        </Route>
      </Routes>
    </Router>
  );
}
