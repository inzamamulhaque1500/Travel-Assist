import React, { useState } from 'react';
import { Plane, CheckCircle2, AlertCircle, CreditCard, Loader2 } from 'lucide-react';

export default function BookingConfirmation() {
  // In a real app, this data would be fetched based on a booking ID from the URL
  const bookingDetails = {
    id: 'TA-847291',
    passengerName: 'John Doe',
    route: 'Delhi (DEL) to London (LHR)',
    airline: 'British Airways',
    departureDate: '15 Apr 2026, 08:00 AM',
    cabinClass: 'Economy',
    status: 'Pending Payment',
    fare: {
      base: 450,
      taxes: 80,
      serviceFee: 20,
      total: 550
    }
  };

  const [paymentMethod, setPaymentMethod] = useState('razorpay');
  const [isProcessing, setIsProcessing] = useState(false);

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handlePayment = async () => {
    if (paymentMethod !== 'razorpay') {
      alert('Redirecting to selected payment gateway...');
      return;
    }

    setIsProcessing(true);
    const res = await loadRazorpayScript();

    if (!res) {
      alert('Razorpay SDK failed to load. Please check your internet connection.');
      setIsProcessing(false);
      return;
    }

    const options = {
      key: (import.meta as any).env.VITE_RAZORPAY_KEY_ID || 'rzp_test_YOUR_KEY_HERE',
      amount: bookingDetails.fare.total * 100, // Amount in subunits (e.g., cents or paise)
      currency: 'USD',
      name: 'Travel Assist',
      description: `Booking Reference: ${bookingDetails.id}`,
      handler: function (response: any) {
        alert(`Payment Successful!\nPayment ID: ${response.razorpay_payment_id}`);
        // In a real app, verify the payment on the backend and redirect to success page
      },
      prefill: {
        name: bookingDetails.passengerName,
        email: 'passenger@example.com',
        contact: '9999999999'
      },
      notes: {
        address: 'Travel Assist Corporate Office'
      },
      theme: {
        color: '#2563eb' // blue-600
      }
    };

    const paymentObject = new (window as any).Razorpay(options);
    paymentObject.on('payment.failed', function (response: any) {
      alert(`Payment Failed: ${response.error.description}`);
    });
    paymentObject.open();
    setIsProcessing(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Booking Confirmation</h1>
        <p className="text-slate-600">Please review your flight details and proceed to payment to issue your tickets.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden mb-8">
        {/* Header */}
        <div className="bg-blue-900 text-white px-6 py-4 flex justify-between items-center">
          <div>
            <p className="text-blue-200 text-sm">Booking Reference</p>
            <p className="text-xl font-mono font-bold">{bookingDetails.id}</p>
          </div>
          <div className="bg-amber-500 text-amber-950 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
            {bookingDetails.status}
          </div>
        </div>

        <div className="p-6 md:p-8">
          {/* Flight Details */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center border-b border-slate-100 pb-2">
              Flight Details
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8 text-sm">
              <div>
                <p className="text-slate-500 mb-1">Route</p>
                <p className="font-medium text-slate-900">{bookingDetails.route}</p>
              </div>
              <div>
                <p className="text-slate-500 mb-1">Departure</p>
                <p className="font-medium text-slate-900">{bookingDetails.departureDate}</p>
              </div>
              <div>
                <p className="text-slate-500 mb-1">Airline</p>
                <p className="font-medium text-slate-900">{bookingDetails.airline}</p>
              </div>
              <div>
                <p className="text-slate-500 mb-1">Cabin Class</p>
                <p className="font-medium text-slate-900">{bookingDetails.cabinClass}</p>
              </div>
            </div>
          </div>

          {/* Passenger Details */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 border-b border-slate-100 pb-2">
              Passenger Details
            </h3>
            <div className="text-sm">
              <p className="text-slate-500 mb-1">Primary Passenger</p>
              <p className="font-medium text-slate-900">{bookingDetails.passengerName}</p>
            </div>
          </div>

          {/* Fare Breakdown */}
          <div className="bg-slate-50 rounded-xl p-6 border border-slate-200 mb-8">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Fare Breakdown</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Base Fare</span>
                <span>USD {bookingDetails.fare.base.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Taxes & Fees</span>
                <span>USD {bookingDetails.fare.taxes.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Service Fee</span>
                <span>USD {bookingDetails.fare.serviceFee.toLocaleString()}</span>
              </div>
              <div className="border-t border-slate-200 pt-3 flex justify-between items-center mt-2">
                <span className="text-base font-bold text-slate-900">Total Amount</span>
                <span className="text-2xl font-bold text-blue-600">USD {bookingDetails.fare.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Payment Details */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 mb-8 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center border-b border-slate-100 pb-2">
              <CreditCard className="w-5 h-5 mr-2 text-blue-600" /> Payment Details
            </h3>
            <div className="space-y-4">
              <label className={`flex items-start p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'razorpay' ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:bg-slate-50'}`}>
                <input 
                  type="radio" 
                  name="payment" 
                  value="razorpay"
                  checked={paymentMethod === 'razorpay'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-4 h-4 mt-1 text-blue-600" 
                />
                <div className="ml-3 flex-1">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-2">
                    <span className="font-medium text-slate-900">Razorpay Secure Payment</span>
                    <div className="flex space-x-2 mt-2 sm:mt-0">
                      <div className="bg-white px-2 py-1 rounded border border-slate-200 text-xs font-bold text-blue-800">VISA</div>
                      <div className="bg-white px-2 py-1 rounded border border-slate-200 text-xs font-bold text-red-600">MasterCard</div>
                      <div className="bg-white px-2 py-1 rounded border border-slate-200 text-xs font-bold text-slate-800">UPI</div>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600">Pay securely using Credit Card, Debit Card, Net Banking, or UPI.</p>
                </div>
              </label>
              
              <label className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'paypal' ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:bg-slate-50'}`}>
                <input 
                  type="radio" 
                  name="payment" 
                  value="paypal"
                  checked={paymentMethod === 'paypal'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-4 h-4 text-blue-600" 
                />
                <div className="ml-3 flex-1 flex justify-between items-center">
                  <span className="font-medium text-slate-900">PayPal</span>
                  <div className="bg-white px-2 py-1 rounded border border-slate-200 text-xs font-bold text-blue-800 italic">PayPal</div>
                </div>
              </label>
            </div>
          </div>

          {/* Terms */}
          <div className="bg-amber-50 rounded-xl p-5 border border-amber-200 mb-8">
            <h4 className="font-semibold text-amber-900 mb-2 flex items-center">
              <AlertCircle className="w-4 h-4 mr-2" /> Terms and Conditions
            </h4>
            <ul className="list-disc list-inside text-sm text-amber-800 space-y-1">
              <li>Passenger must verify all details before payment.</li>
              <li>Tickets are issued only after payment confirmation.</li>
              <li>Airline cancellation and modification rules apply.</li>
              <li>Fares are subject to change until ticketed.</li>
            </ul>
          </div>

          {/* Action */}
          <button 
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-4 px-6 rounded-xl transition-colors shadow-lg flex items-center justify-center text-lg"
          >
            {isProcessing ? (
              <><Loader2 className="w-6 h-6 mr-2 animate-spin" /> Processing...</>
            ) : (
              <><CheckCircle2 className="w-6 h-6 mr-2" /> Confirm & Proceed to Payment</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
