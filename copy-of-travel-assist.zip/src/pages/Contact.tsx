import React, { useState } from 'react';
import { Phone, Mail, MessageCircle, MapPin, Send } from 'lucide-react';

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const waMessage = `*New Contact Message*
*Name:* ${name}
*Email:* ${email}
*Message:* ${message}`;

    try {
      await fetch("https://formsubmit.co/ajax/travelassisthelp1@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          _subject: "New Contact Message - Travel Assist",
          name: name,
          email: email,
          message: message
        })
      });
    } catch (error) {
      console.error("Error submitting form", error);
    }

    setIsSubmitting(false);
    setIsSuccess(true);
  };

  return (
    <div className="bg-slate-50 py-12 min-h-[calc(100vh-4rem)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Contact Us</h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Have questions about a booking or need help finding the best flight? Our travel experts are here to assist you 24/7.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 mb-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-6 border-b border-slate-100 pb-4">Get in Touch</h2>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center shrink-0 mr-4">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Phone Support</h3>
                    <p className="text-slate-600 mb-2">Available 24/7 for urgent booking assistance.</p>
                    <a href="tel:8582942118" className="text-lg font-bold text-blue-600 hover:underline">8582942118</a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center shrink-0 mr-4">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">WhatsApp Chat</h3>
                    <p className="text-slate-600 mb-2">Quick responses for flight quotes and queries.</p>
                    <a href="https://wa.me/918582942118" target="_blank" rel="noreferrer" className="inline-flex items-center bg-green-500 hover:bg-green-600 text-white font-medium px-4 py-2 rounded-lg transition-colors">
                      <MessageCircle className="w-4 h-4 mr-2" /> Chat Now
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center shrink-0 mr-4">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-1">Email Support</h3>
                    <p className="text-slate-600 mb-2">For detailed itineraries and corporate bookings.</p>
                    <a href="mailto:travelassisthelp1@gmail.com" className="text-lg font-bold text-blue-600 hover:underline break-all">travelassisthelp1@gmail.com</a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-900 rounded-2xl shadow-lg p-8 text-white">
              <h3 className="text-xl font-bold mb-4">Why Book With Us?</h3>
              <ul className="space-y-3">
                <li className="flex items-center"><div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div> Personalized travel assistance</li>
                <li className="flex items-center"><div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div> Competitive flight deals worldwide</li>
                <li className="flex items-center"><div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div> Secure payment processing via Razorpay</li>
                <li className="flex items-center"><div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div> 24/7 post-booking support</li>
              </ul>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <div className="bg-white rounded-2xl shadow-xl border border-slate-100 p-8 h-full">
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Send us a Message</h2>
              
              {isSuccess ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Message Sent!</h3>
                  <p className="text-slate-600 mb-6">Your message has been submitted to our team. A travel expert will contact you soon.</p>
                  <button 
                    onClick={() => setIsSuccess(false)}
                    className="text-blue-600 font-medium hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Your Name *</label>
                    <input 
                      type="text" 
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email Address *</label>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                      placeholder="john@example.com"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Message *</label>
                    <textarea 
                      required
                      rows={5}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
                      placeholder="How can we help you today?"
                    ></textarea>
                  </div>
                  
                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-4 px-6 rounded-xl transition-colors shadow-md flex items-center justify-center"
                  >
                    {isSubmitting ? 'Sending...' : <><Send className="w-5 h-5 mr-2" /> Send Message</>}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
