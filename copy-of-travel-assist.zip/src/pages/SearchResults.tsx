import { useSearchParams, useNavigate } from 'react-router-dom';
import { Plane, Clock, Info, Briefcase, Luggage, ShieldCheck, Star } from 'lucide-react';
import { AIRLINES } from '../data/airlines';

// Major Hubs for stops
const HUBS = ['DXB', 'SIN', 'LHR', 'FRA', 'IST', 'JFK', 'LAX', 'BOM', 'DEL', 'HKG', 'HND', 'CDG', 'AMS', 'DOH', 'AUH'];

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const from = searchParams.get('from') || 'LAX';
  const to = searchParams.get('to') || 'NYC';
  const date = searchParams.get('date') || '2026-03-26';
  const passengers = searchParams.get('passengers') || '1';
  const cabinClass = searchParams.get('class') || 'Economy';

  // Generate dynamic flights based on search
  const generateFlights = () => {
    const flights = [];
    const numFlights = 6 + Math.floor(Math.random() * 5); // 6-10 flights
    
    // Indian domestic hubs
    const indianHubs = ['DEL', 'BOM', 'CCU', 'BLR', 'MAA', 'HYD', 'PNQ', 'AMD'];
    const isDomestic = indianHubs.includes(from) && indianHubs.includes(to);

    // Filter airlines based on route
    const domesticAirlines = AIRLINES.filter(a => ['AI', '6E', 'UK'].includes(a.code));
    const availableAirlines = isDomestic ? domesticAirlines : AIRLINES;

    for (let i = 0; i < numFlights; i++) {
      const airline = availableAirlines[Math.floor(Math.random() * availableAirlines.length)];
      const depHour = Math.floor(Math.random() * 24);
      const depMin = Math.floor(Math.random() * 60);
      
      // Realistic duration
      let durationHours = isDomestic ? 1 + Math.floor(Math.random() * 2) : 5 + Math.floor(Math.random() * 15);
      let durationMins = Math.floor(Math.random() * 60);
      
      // Special case for DEL-CCU which is about 2h 15m
      if (from === 'DEL' && to === 'CCU') {
        durationHours = 2;
        durationMins = 10 + Math.floor(Math.random() * 20);
      }

      const arrivalTotalMins = (depHour * 60 + depMin + durationHours * 60 + durationMins) % (24 * 60);
      const arrHour = Math.floor(arrivalTotalMins / 60);
      const arrMin = arrivalTotalMins % 60;

      const stopsCount = isDomestic ? 0 : Math.floor(Math.random() * 2); // 0 or 1 stops for international, 0 for domestic
      const stops = stopsCount === 0 ? 'Non-stop' : 
                    stopsCount === 1 ? HUBS[Math.floor(Math.random() * HUBS.length)] :
                    `${HUBS[Math.floor(Math.random() * HUBS.length)]}, ${HUBS[Math.floor(Math.random() * HUBS.length)]}`;

      // Realistic price generation in USD
      let basePrice = isDomestic ? 50 + Math.floor(Math.random() * 100) : 450 + Math.floor(Math.random() * 800);
      
      // Adjust for cabin class
      if (cabinClass === 'Business') basePrice *= 3.5;
      if (cabinClass === 'First Class') basePrice *= 6;
      if (cabinClass === 'Premium Economy') basePrice *= 1.6;

      // Add 150 as requested
      basePrice += 150;

      flights.push({
        id: `f-${i}-${airline.code}`,
        airline: airline.name,
        logo: airline.logo,
        code: `${airline.code} ${100 + Math.floor(Math.random() * 900)}`,
        departureTime: `${depHour.toString().padStart(2, '0')}:${depMin.toString().padStart(2, '0')}`,
        arrivalTime: `${arrHour.toString().padStart(2, '0')}:${arrMin.toString().padStart(2, '0')}`,
        duration: `${durationHours}h ${durationMins}m`,
        stops: stops,
        stopsCount: stopsCount,
        cabin: cabinClass,
        rating: (4 + Math.random()).toFixed(1),
        price: Math.floor(basePrice)
      });
    }
    
    return flights;
  };

  const flights = generateFlights();

  const handleBookNow = (flightId: string, price: number) => {
    navigate(`/booking-request?flightId=${flightId}&from=${from}&to=${to}&date=${date}&passengers=${passengers}&class=${cabinClass}&price=${price}`);
  };

  // For demo, we'll show mock flights for common routes, but a "Contact Agent" message for others
  const isCommonRoute = true; // Always show flights now as requested for professional look

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Search Header */}
      <div className="bg-white border-b border-slate-200 py-4 px-4 sticky top-[72px] z-40 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-lg font-bold text-slate-900">
              <span>{from}</span>
              <span className="text-orange-600 mx-1">→</span>
              <span>{to}</span>
            </div>
            <div className="text-xs text-slate-500 font-medium">
              {new Date(date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })} • {passengers} Traveler • {cabinClass}
            </div>
          </div>
          <button 
            onClick={() => navigate('/')}
            className="p-2 bg-orange-100 text-orange-600 rounded-lg hover:bg-orange-200 transition-colors"
          >
            <Info className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {!isCommonRoute && (
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6 mb-8 text-center">
            <Plane className="w-12 h-12 text-orange-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-900 mb-2">No direct online results found for this route</h2>
            <p className="text-slate-600 mb-6">Due to high demand or complex routing, these flights are currently only available via our offline booking desk.</p>
            <button 
              onClick={() => navigate(`/booking-request?from=${from}&to=${to}&date=${date}&passengers=${passengers}&class=${cabinClass}`)}
              className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Request Custom Quote from Agent
            </button>
          </div>
        )}

        {/* Sort/Filter Controls */}
        <div className="flex space-x-2 mb-6">
          <button className="flex-1 bg-white border border-slate-200 rounded-lg py-2 px-4 flex items-center justify-between text-sm font-bold text-slate-700">
            <div className="flex items-center">
              <div className="w-4 h-4 border-2 border-slate-300 mr-2"></div>
              Sort By
            </div>
            <span className="text-slate-400">▼</span>
          </button>
          <button className="flex-1 bg-white border border-slate-200 rounded-lg py-2 px-4 flex items-center justify-between text-sm font-bold text-slate-700">
            <div className="flex items-center">
              <div className="w-4 h-4 border-2 border-slate-300 mr-2"></div>
              Filter By
            </div>
            <span className="text-slate-400">▼</span>
          </button>
        </div>

        {/* Flight Cards */}
        <div className="space-y-4">
          {flights.map((flight) => (
            <div key={flight.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="bg-orange-100 text-orange-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                      Top Rated
                    </div>
                    <div className="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded flex items-center">
                      <Star className="w-3 h-3 mr-1 fill-blue-600" /> {flight.rating} Rating
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-slate-400">Flight {flight.code}</div>
                    <div className="text-lg font-black text-blue-600">${flight.price.toLocaleString()}</div>
                  </div>
                </div>

                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <img src={flight.logo} alt={flight.airline} className="w-10 h-10 object-contain" referrerPolicy="no-referrer" />
                    <div>
                      <h3 className="font-bold text-slate-900">{flight.airline}</h3>
                      <p className="text-xs text-slate-500 uppercase font-bold tracking-tight">{flight.cabin}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-6">
                  <div className="text-left">
                    <p className="text-2xl font-bold text-slate-900">{flight.departureTime}</p>
                    <p className="text-xs font-bold text-slate-500 uppercase">{from}</p>
                  </div>
                  
                  <div className="flex-1 flex flex-col items-center px-6">
                    <p className="text-xs text-slate-500 font-bold mb-1">{flight.duration}</p>
                    <div className="w-full h-px bg-slate-200 relative">
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-1.5 border border-slate-300 bg-white rounded-full"></div>
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-1.5 border border-slate-300 bg-white rounded-full"></div>
                      {flight.stopsCount > 0 && (
                        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                      )}
                    </div>
                    <p className={`text-xs font-bold mt-1 uppercase ${flight.stopsCount === 0 ? 'text-green-600' : 'text-orange-600'}`}>
                      {flight.stops}
                    </p>
                  </div>

                  <div className="text-right">
                    <p className="text-2xl font-bold text-slate-900">{flight.arrivalTime}</p>
                    <p className="text-xs font-bold text-slate-500 uppercase">{to}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-slate-100 pt-4">
                  <div className="flex space-x-6">
                    <div className="flex items-center text-slate-500">
                      <Briefcase className="w-4 h-4 mr-1.5" />
                      <span className="text-xs font-bold">7kg Cabin</span>
                    </div>
                    <div className="flex items-center text-slate-500">
                      <Luggage className="w-4 h-4 mr-1.5" />
                      <span className="text-xs font-bold">23kg Checked</span>
                    </div>
                    <div className="flex items-center text-green-600">
                      <ShieldCheck className="w-4 h-4 mr-1.5" />
                      <span className="text-xs font-bold">Refundable</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-6">
                    <div className="text-right mr-4">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter">Price per traveler</p>
                      <p className="text-2xl font-black text-slate-900">${flight.price.toLocaleString()}</p>
                    </div>
                    <button 
                      onClick={() => handleBookNow(flight.id, flight.price)}
                      className="bg-orange-600 hover:bg-orange-700 text-white font-bold py-2.5 px-10 rounded-lg transition-colors uppercase tracking-wider shadow-sm"
                    >
                      Select
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

