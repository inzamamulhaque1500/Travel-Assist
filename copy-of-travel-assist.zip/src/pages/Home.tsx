import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Users, ShieldCheck, Clock, ThumbsUp, Phone, MessageCircle, Plane, Hotel, Ship, Package, Car, Star, CheckCircle, ChevronDown, Armchair } from 'lucide-react';
import { motion } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import AirportInput from '../components/AirportInput';
import PopularRoutes from '../components/PopularRoutes';

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export default function Home() {
  const navigate = useNavigate();
  const [tripType, setTripType] = useState('round');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [departDate, setDepartDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [passengers, setPassengers] = useState('1');
  const [cabinClass, setCabinClass] = useState('Economy');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (from && to && departDate) {
      navigate(`/results?from=${from}&to=${to}&date=${departDate}&passengers=${passengers}&class=${cabinClass}`);
    }
  };

  return (
    <div className="bg-slate-50">
      {/* Hero Section with Flight Background */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1570710891163-6d3b5c47248b?auto=format&fit=crop&w=1920&q=80" 
            alt="Premium Flight Experience" 
            className="w-full h-full object-cover brightness-[0.6]"
            referrerPolicy="no-referrer"
          />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-8xl font-black text-white mb-6 tracking-tighter drop-shadow-2xl uppercase">
              EXPERIENCE <span className="text-orange-500">EXCELLENCE</span>
            </h1>
            <p className="text-xl md:text-3xl text-white/95 font-medium italic drop-shadow-lg max-w-3xl mx-auto">
              Fly with the World's Most Unique Airline
            </p>
          </motion.div>
        </div>
      </section>

      <section className="relative -mt-24 pb-20 px-4 z-20">
        <div className="max-w-7xl mx-auto">
          {/* Search Form */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 max-w-5xl mx-auto text-slate-900 border border-slate-200">
            <div className="flex space-x-6 mb-8">
              <button 
                className={`flex items-center font-bold text-sm transition-colors ${tripType === 'round' ? 'text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                onClick={() => setTripType('round')}
              >
                <div className={`w-4 h-4 rounded-full border-2 mr-2 flex items-center justify-center ${tripType === 'round' ? 'border-orange-600' : 'border-slate-300'}`}>
                  {tripType === 'round' && <div className="w-2 h-2 bg-orange-600 rounded-full"></div>}
                </div>
                Round Trip
              </button>
              <button 
                className={`flex items-center font-bold text-sm transition-colors ${tripType === 'one' ? 'text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                onClick={() => setTripType('one')}
              >
                <div className={`w-4 h-4 rounded-full border-2 mr-2 flex items-center justify-center ${tripType === 'one' ? 'border-orange-600' : 'border-slate-300'}`}>
                  {tripType === 'one' && <div className="w-2 h-2 bg-orange-600 rounded-full"></div>}
                </div>
                One Way
              </button>
            </div>

            <form onSubmit={handleSearch}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="relative">
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Origin</label>
                  <AirportInput value={from} onChange={setFrom} placeholder="Origin" type="from" />
                </div>
                <div className="relative">
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Destination</label>
                  <AirportInput value={to} onChange={setTo} placeholder="Destination" type="to" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Departure Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <input 
                        type="date" 
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                        value={departDate}
                        onChange={(e) => setDepartDate(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="relative">
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Return Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <input 
                        type="date" 
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none disabled:opacity-50"
                        value={returnDate}
                        onChange={(e) => setReturnDate(e.target.value)}
                        disabled={tripType === 'one'}
                        required={tripType === 'round'}
                      />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Travelers</label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <select 
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                        value={passengers}
                        onChange={(e) => setPassengers(e.target.value)}
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                          <option key={num} value={num.toString()}>{num} {num === 1 ? 'Traveler' : 'Travelers'}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
                    </div>
                  </div>
                  <div className="relative">
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Cabin Class</label>
                    <div className="relative">
                      <Armchair className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <select 
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                        value={cabinClass}
                        onChange={(e) => setCabinClass(e.target.value)}
                      >
                        <option value="Economy">Economy</option>
                        <option value="Premium Economy">Premium Economy</option>
                        <option value="Business">Business</option>
                        <option value="First Class">First Class</option>
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
                    </div>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 px-6 rounded-lg transition-colors shadow-lg text-xl uppercase tracking-wider">
                Search Flights
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Hotspots Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-slate-900">Global Vacation Hotspots</h2>
            <div className="flex space-x-2">
              <button className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-50">
                <Phone className="w-5 h-5 rotate-90" />
              </button>
              <button className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-50">
                <Phone className="w-5 h-5 -rotate-90" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Paris, France', img: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80' },
              { title: 'Bali, Indonesia', img: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=800&q=80' },
              { title: 'New York, USA', img: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=800&q=80' },
            ].map((spot, idx) => (
              <div key={idx} className="group cursor-pointer">
                <div className="relative h-64 rounded-2xl overflow-hidden mb-4">
                  <img src={spot.img} alt={spot.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <h3 className="text-xl font-bold text-white">{spot.title}</h3>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex items-start space-x-4">
              <div className="bg-orange-100 p-3 rounded-xl text-orange-600">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Secure Payments</h3>
                <p className="text-slate-600">Your transactions are protected with industry-leading security protocols.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-orange-100 p-3 rounded-xl text-orange-600">
                <Clock className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">24/7 Assistance</h3>
                <p className="text-slate-600">Our expert travel agents are available around the clock to support you.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-orange-100 p-3 rounded-xl text-orange-600">
                <ThumbsUp className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Best Price Support</h3>
                <p className="text-slate-600">We help you find the most competitive fares for your desired routes.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <PopularRoutes />
    </div>
  );
}

