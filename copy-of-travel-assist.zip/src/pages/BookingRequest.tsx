import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Plane, User, Mail, Phone, Calendar, ShieldCheck, Lock, ChevronDown, ChevronUp, CreditCard, MapPin, Armchair, Info } from 'lucide-react';
import { COUNTRIES } from '../data/countries';

export default function BookingRequest() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [expandedSection, setExpandedSection] = useState('traveler');

  const from = searchParams.get('from') || 'DEL';
  const to = searchParams.get('to') || 'CCU';
  const date = searchParams.get('date') || '2026-03-26';
  const passengersCount = parseInt(searchParams.get('passengers') || '1', 10);
  const cabinClass = searchParams.get('class') || 'Economy';
  const pricePerPerson = parseInt(searchParams.get('price') || '53500', 10);

  const initialPassenger = {
    fullName: '',
    gender: '',
    dob: '',
    passengerType: 'Adult',
    passportNumber: '',
    passportIssueDate: '',
    passportExpiryDate: '',
    nationality: '',
    countryOfResidence: '',
    contactNumber: '',
    email: '',
    originCity: from,
    destinationCity: to,
    flightDate: date,
    cabinClass: cabinClass,
    mealPreference: '',
    seatPreference: '',
    baggageRequirement: '',
    visaStatus: '',
    specialAssistance: '',
    remarks: '',
    // Logic specific fields
    infantOption: '', // 'lap' or 'seat'
    guardianDetails: '',
    needsSpecialAssistance: false,
    assistanceType: [] as string[],
  };

  const [passengers, setPassengers] = useState(
    Array.from({ length: Math.min(Math.max(passengersCount, 1), 9) }, () => ({ ...initialPassenger }))
  );

  const calculatePassengerType = (dob: string) => {
    if (!dob) return 'Adult';
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 2) return 'Infant';
    if (age >= 2 && age <= 11) return 'Child';
    if (age >= 12 && age <= 17) return 'Youth / Teen';
    if (age >= 60) return 'Senior / Elderly';
    return 'Adult';
  };

  const handlePassengerChange = (index: number, field: string, value: any) => {
    const updatedPassengers = [...passengers];
    updatedPassengers[index] = { ...updatedPassengers[index], [field]: value };
    
    if (field === 'dob') {
      updatedPassengers[index].passengerType = calculatePassengerType(value);
    }
    
    setPassengers(updatedPassengers);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      let passengersHtml = '';
      passengers.forEach((p, i) => {
        passengersHtml += `
          <div style="background-color: #fff7ed; padding: 15px; border-radius: 8px; margin: 20px 0; border: 1px solid #ffedd5;">
            <h3 style="margin-top: 0; font-size: 16px; color: #9a3412;">Passenger ${i + 1} (${p.passengerType})</h3>
            <p style="margin: 5px 0;"><strong>Full Name:</strong> ${p.fullName || '---'}</p>
            <p style="margin: 5px 0;"><strong>Gender:</strong> ${p.gender || '---'}</p>
            <p style="margin: 5px 0;"><strong>DOB:</strong> ${p.dob || '---'}</p>
            <p style="margin: 5px 0;"><strong>Passport No:</strong> ${p.passportNumber || '---'}</p>
            <p style="margin: 5px 0;"><strong>Passport Issue:</strong> ${p.passportIssueDate || '---'}</p>
            <p style="margin: 5px 0;"><strong>Passport Expiry:</strong> ${p.passportExpiryDate || '---'}</p>
            <p style="margin: 5px 0;"><strong>Nationality:</strong> ${p.nationality || '---'}</p>
            <p style="margin: 5px 0;"><strong>Residence:</strong> ${p.countryOfResidence || '---'}</p>
            <p style="margin: 5px 0;"><strong>Contact:</strong> ${p.contactNumber || '---'}</p>
            <p style="margin: 5px 0;"><strong>Email:</strong> ${p.email || '---'}</p>
            <p style="margin: 5px 0;"><strong>Route:</strong> ${p.originCity} to ${p.destinationCity}</p>
            <p style="margin: 5px 0;"><strong>Flight Date:</strong> ${p.flightDate}</p>
            <p style="margin: 5px 0;"><strong>Cabin:</strong> ${p.cabinClass}</p>
            <p style="margin: 5px 0;"><strong>Meal:</strong> ${p.mealPreference || '---'}</p>
            <p style="margin: 5px 0;"><strong>Seat:</strong> ${p.seatPreference || '---'}</p>
            <p style="margin: 5px 0;"><strong>Baggage:</strong> ${p.baggageRequirement || '---'}</p>
            <p style="margin: 5px 0;"><strong>Visa Status:</strong> ${p.visaStatus || '---'}</p>
            ${p.passengerType === 'Infant' ? `<p style="margin: 5px 0;"><strong>Infant Option:</strong> ${p.infantOption || '---'}</p>` : ''}
            ${p.passengerType === 'Child' ? `<p style="margin: 5px 0;"><strong>Guardian:</strong> ${p.guardianDetails || '---'}</p>` : ''}
            ${p.needsSpecialAssistance ? `<p style="margin: 5px 0;"><strong>Special Assistance:</strong> ${p.assistanceType.join(', ') || p.specialAssistance || '---'}</p>` : ''}
            <p style="margin: 5px 0;"><strong>Remarks:</strong> ${p.remarks || '---'}</p>
          </div>
        `;
      });

      const emailHtml = `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px;">
              <h2 style="color: #ea580c;">International Booking Request Received!</h2>
              <p>Dear Customer,</p>
              <p>Thank you for submitting your booking request for ${passengers.length} passenger(s). Our travel experts are currently reviewing the best options for your journey.</p>
              
              <div style="background-color: #f8fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; font-size: 16px; color: #1e293b;">Journey Overview</h3>
                <p style="margin: 5px 0;"><strong>Route:</strong> ${from} &rarr; ${to}</p>
                <p style="margin: 5px 0;"><strong>Date:</strong> ${date}</p>
                <p style="margin: 5px 0;"><strong>Total Passengers:</strong> ${passengers.length}</p>
                <p style="margin: 5px 0;"><strong>Class:</strong> ${cabinClass}</p>
                <p style="margin: 5px 0; color: #2563eb; font-size: 18px;"><strong>Estimated Total Price:</strong> $${(passengers.length * pricePerPerson).toLocaleString()}</p>
              </div>

              ${passengersHtml}
              
              <h3 style="font-size: 16px; color: #1e293b;">What happens next?</h3>
              <ol style="color: #475569;">
                <li>Our agent verifies current flight prices, visa requirements, and availability.</li>
                <li>We send you a secure payment link via email/WhatsApp.</li>
                <li>You review the final PNR details and complete the payment.</li>
                <li>We issue your official e-tickets immediately after payment.</li>
              </ol>
              
              <p style="color: #64748b; font-size: 14px; margin-top: 30px; border-top: 1px solid #e2e8f0; padding-top: 20px;">
                If you have any questions, feel free to contact us at +91 85829 42118.
              </p>
              <p style="color: #64748b; font-size: 14px;">Best regards,<br>The Travel Assist Team</p>
            </div>
          `;

      const response1 = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: passengers[0].email || 'travelassisthelp1@gmail.com',
          subject: `International Booking Request: ${from} to ${to} (${passengers.length} Pax)`,
          html: emailHtml
        }),
      });
      const result1 = await response1.json();
      if (!result1.success) {
        console.error('Email 1 failed:', result1.error);
      }

      // Also send to admin
      const response2 = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: 'travelassisthelp1@gmail.com',
          subject: `NEW PNR REQUEST: ${from} to ${to} (${passengers.length} Pax)`,
          html: emailHtml
        }),
      });
      const result2 = await response2.json();
      if (!result2.success) {
        console.error('Email 2 failed:', result2.error);
      }

      setIsSuccess(true);
      setIsSubmitting(false);
    } catch (error: any) {
      console.error('Submission error:', error);
      setIsSubmitting(false);
      alert(`There was an error processing your request: ${error.message || 'Unknown error'}. Please try again.`);
    }
  };

  if (isSuccess) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-4">PNR Request Submitted!</h2>
        <p className="text-lg text-slate-600 mb-8">
          Your international booking request for {passengers.length} passenger(s) has been received. A travel expert will contact you shortly with the best fares and visa guidance.
        </p>
        <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-8 text-left max-w-md mx-auto">
          <h3 className="font-semibold text-slate-900 mb-4 border-b border-slate-200 pb-2">Next Steps</h3>
          <ol className="list-decimal list-inside space-y-3 text-slate-600 text-sm">
            <li>Agent verifies fares and passport validity.</li>
            <li>We send you a <strong>secure manual payment link</strong>.</li>
            <li>Review and pay to confirm your seats.</li>
            <li>E-tickets issued within minutes of payment.</li>
          </ol>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a 
            href="tel:+918582942118"
            className="bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-8 rounded-lg transition-colors flex items-center"
          >
            <Phone className="w-5 h-5 mr-2" />
            Contact Booking Expert
          </a>
          <button 
            onClick={() => navigate('/')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-lg transition-colors"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen pb-12">
      {/* Checkout Header */}
      <div className="bg-white border-b border-slate-200 py-4 px-4 sticky top-[72px] z-40 shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 rounded-full">
            <ChevronDown className="w-6 h-6 rotate-90" />
          </button>
          <div className="flex items-center text-green-600 font-bold">
            <Lock className="w-4 h-4 mr-2" />
            Secure International Booking
          </div>
          <div className="w-10"></div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-6">
        {/* Journey Summary */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
          <div className="bg-blue-900 text-white px-6 py-4 flex items-center justify-between">
            <h2 className="text-lg font-bold">International PNR Entry</h2>
            <div className="text-sm opacity-80">{passengers.length} Passenger(s)</div>
          </div>
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Plane className="w-8 h-8 text-blue-600 mr-4" />
                <div>
                  <div className="font-bold text-slate-900">{from} &rarr; {to}</div>
                  <div className="text-xs text-slate-500">{cabinClass} Class • {date}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-tighter">Total Price</div>
                <div className="text-2xl font-black text-blue-600">${(passengers.length * pricePerPerson).toLocaleString()}</div>
              </div>
              <div className="hidden md:block">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-500">
                      P{i}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {passengers.map((p, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-900 flex items-center">
                  <User className="w-5 h-5 mr-2 text-orange-600" />
                  Passenger {index + 1}
                  <span className="ml-3 text-sm font-medium text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {p.passengerType}
                  </span>
                </h2>
              </div>
              
              <div className="p-6 space-y-6">
                {/* Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Full Name (as per Passport)*</label>
                    <input 
                      type="text" 
                      value={p.fullName} 
                      onChange={(e) => handlePassengerChange(index, 'fullName', e.target.value)} 
                      placeholder="SURNAME GIVEN NAMES" 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Gender*</label>
                      <select 
                        value={p.gender} 
                        onChange={(e) => handlePassengerChange(index, 'gender', e.target.value)} 
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                        required
                      >
                        <option value="">Select</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Date of Birth*</label>
                      <input 
                        type="date" 
                        value={p.dob} 
                        onChange={(e) => handlePassengerChange(index, 'dob', e.target.value)} 
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                        required 
                      />
                    </div>
                  </div>
                </div>

                {/* Passport Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-100 pt-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Passport Number*</label>
                    <input 
                      type="text" 
                      value={p.passportNumber} 
                      onChange={(e) => handlePassengerChange(index, 'passportNumber', e.target.value)} 
                      placeholder="Passport No." 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Passport Issue Date*</label>
                    <input 
                      type="date" 
                      value={p.passportIssueDate} 
                      onChange={(e) => handlePassengerChange(index, 'passportIssueDate', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Passport Expiry Date*</label>
                    <input 
                      type="date" 
                      value={p.passportExpiryDate} 
                      onChange={(e) => handlePassengerChange(index, 'passportExpiryDate', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                </div>

                {/* Nationality & Residence */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Nationality*</label>
                    <select 
                      value={p.nationality} 
                      onChange={(e) => handlePassengerChange(index, 'nationality', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                      required
                    >
                      <option value="">Select Country</option>
                      {COUNTRIES.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Country of Residence*</label>
                    <select 
                      value={p.countryOfResidence} 
                      onChange={(e) => handlePassengerChange(index, 'countryOfResidence', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                      required
                    >
                      <option value="">Select Country</option>
                      {COUNTRIES.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 pt-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Contact Number*</label>
                    <input 
                      type="tel" 
                      value={p.contactNumber} 
                      onChange={(e) => handlePassengerChange(index, 'contactNumber', e.target.value)} 
                      placeholder="+91 00000 00000" 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Email Address*</label>
                    <input 
                      type="email" 
                      value={p.email} 
                      onChange={(e) => handlePassengerChange(index, 'email', e.target.value)} 
                      placeholder="email@example.com" 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium" 
                      required 
                    />
                  </div>
                </div>

                {/* Preferences */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Meal Preference</label>
                    <select 
                      value={p.mealPreference} 
                      onChange={(e) => handlePassengerChange(index, 'mealPreference', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                    >
                      <option value="">No Preference</option>
                      <option>Vegetarian Hindu Meal (AVML)</option>
                      <option>Vegetarian Jain Meal (VJML)</option>
                      <option>Kosher Meal (KSML)</option>
                      <option>Muslim Meal (MOML)</option>
                      <option>Gluten-Free Meal (GFML)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Seat Preference</label>
                    <select 
                      value={p.seatPreference} 
                      onChange={(e) => handlePassengerChange(index, 'seatPreference', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                    >
                      <option value="">No Preference</option>
                      <option>Window</option>
                      <option>Aisle</option>
                      <option>Extra Legroom</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Baggage Requirement</label>
                    <select 
                      value={p.baggageRequirement} 
                      onChange={(e) => handlePassengerChange(index, 'baggageRequirement', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                    >
                      <option value="">Standard</option>
                      <option>Extra 10kg</option>
                      <option>Extra 20kg</option>
                      <option>Sports Equipment</option>
                    </select>
                  </div>
                </div>

                {/* Conditional Logic Fields */}
                {p.passengerType === 'Infant' && (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                    <label className="block text-xs font-bold text-blue-600 uppercase mb-2">Infant Booking Option*</label>
                    <div className="flex space-x-4">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name={`infant-${index}`} 
                          value="lap" 
                          checked={p.infantOption === 'lap'} 
                          onChange={(e) => handlePassengerChange(index, 'infantOption', e.target.value)} 
                        />
                        <span className="text-sm font-medium">Lap Infant</span>
                      </label>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name={`infant-${index}`} 
                          value="seat" 
                          checked={p.infantOption === 'seat'} 
                          onChange={(e) => handlePassengerChange(index, 'infantOption', e.target.value)} 
                        />
                        <span className="text-sm font-medium">Infant with Seat</span>
                      </label>
                    </div>
                  </div>
                )}

                {p.passengerType === 'Child' && (
                  <div className="bg-orange-50 p-4 rounded-lg border border-orange-100">
                    <label className="block text-xs font-bold text-orange-600 uppercase mb-1">Guardian / Adult Companion Details*</label>
                    <input 
                      type="text" 
                      value={p.guardianDetails} 
                      onChange={(e) => handlePassengerChange(index, 'guardianDetails', e.target.value)} 
                      placeholder="Name of adult traveling with child" 
                      className="w-full px-4 py-2 bg-white border border-orange-200 rounded-lg outline-none text-sm" 
                      required 
                    />
                  </div>
                )}

                {(p.passengerType === 'Senior / Elderly' || p.needsSpecialAssistance) && (
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-3">
                      <label className="text-xs font-bold text-slate-600 uppercase">Special Assistance</label>
                      <div className="flex items-center">
                        <input 
                          type="checkbox" 
                          checked={p.needsSpecialAssistance} 
                          onChange={(e) => handlePassengerChange(index, 'needsSpecialAssistance', e.target.checked)} 
                          className="mr-2"
                        />
                        <span className="text-xs font-bold text-slate-500">Required</span>
                      </div>
                    </div>
                    {p.needsSpecialAssistance && (
                      <div className="grid grid-cols-2 gap-2">
                        {['Wheelchair', 'Priority Boarding', 'Walking Support', 'Medical Assistance', 'Oxygen'].map(type => (
                          <label key={type} className="flex items-center space-x-2 text-xs font-medium text-slate-600">
                            <input 
                              type="checkbox" 
                              checked={p.assistanceType.includes(type)} 
                              onChange={(e) => {
                                const types = e.target.checked 
                                  ? [...p.assistanceType, type]
                                  : p.assistanceType.filter(t => t !== type);
                                handlePassengerChange(index, 'assistanceType', types);
                              }}
                            />
                            <span>{type}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Visa & Remarks */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 pt-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Visa Status / Requirement*</label>
                    <select 
                      value={p.visaStatus} 
                      onChange={(e) => handlePassengerChange(index, 'visaStatus', e.target.value)} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none appearance-none font-medium"
                      required
                    >
                      <option value="">Select Status</option>
                      <option>Valid Visa Held</option>
                      <option>Visa on Arrival Eligible</option>
                      <option>E-Visa Required</option>
                      <option>Sticker Visa Required</option>
                      <option>Transit Visa Required</option>
                      <option>Not Required (Citizen/Resident)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Remarks / Special Requests</label>
                    <input 
                      type="text"
                      value={p.remarks} 
                      onChange={(e) => handlePassengerChange(index, 'remarks', e.target.value)} 
                      placeholder="Any additional information..." 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none font-medium"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Price Summary Card */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-bold flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-green-400" />
                Price Summary & Fare Rules
              </h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center text-slate-600">
                <span>Base Fare ({passengers.length} Passenger{passengers.length > 1 ? 's' : ''})</span>
                <span className="font-bold">${((passengers.length * Math.floor(pricePerPerson * 0.85))).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span>Taxes & Fees</span>
                <span className="font-bold">${((passengers.length * Math.floor(pricePerPerson * 0.15))).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600 border-t border-slate-100 pt-4">
                <span className="text-lg font-bold text-slate-900">Total Amount</span>
                <span className="text-2xl font-black text-blue-600">${((passengers.length * pricePerPerson)).toLocaleString()}</span>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mt-4">
                <div className="flex items-start">
                  <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5" />
                  <div className="text-xs text-blue-800 leading-relaxed">
                    <p className="font-bold mb-1 uppercase">Fare Policy:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Prices are subject to change until ticket issuance.</li>
                      <li>Cancellation fees apply as per airline policy.</li>
                      <li>Passport must be valid for at least 6 months from travel date.</li>
                      <li>Visa verification is the responsibility of the traveler.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-6">
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-orange-600 hover:bg-orange-700 disabled:bg-orange-300 text-white font-bold py-4 px-6 rounded-lg transition-colors shadow-lg text-xl uppercase tracking-wider flex items-center justify-center"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Generating PNR...
                </>
              ) : (
                'Submit International Booking Request'
              )}
            </button>
            <div className="flex items-center justify-center mt-4 text-slate-500">
              <ShieldCheck className="w-4 h-4 mr-2" />
              <span className="text-xs font-bold uppercase tracking-tighter">Secure 256-bit Encrypted Submission</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

