import React from 'react';
import { Shield, FileText, Lock, RefreshCcw, AlertCircle, HelpCircle, Package, Ship, CheckCircle } from 'lucide-react';

export default function Policies() {
  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-[#1a2b48] text-white px-8 py-10">
            <h1 className="text-3xl font-bold mb-2">TRAVEL ASSIST – WEBSITE INFORMATION, POLICIES & LEGAL NOTICE</h1>
            <p className="opacity-80">Last Updated: March 2026</p>
          </div>
          
          <div className="p-8 space-y-10">
            {/* Business Info */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Business Information</h2>
              </div>
              <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <p className="font-bold text-slate-900">Business Name: <span className="font-normal">Travel Assist</span></p>
                <p className="font-bold text-slate-900">Customer Support Phone / WhatsApp: <span className="font-normal">+91 8582942118</span></p>
                <p className="font-bold text-slate-900">Support Email: <span className="font-normal">travelassisthelp1@gmail.com</span></p>
              </div>
            </section>

            {/* About */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <HelpCircle className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">About Travel Assist</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>
                  Travel Assist is an independent travel support provider. We help customers check flight schedules, availability, and prices. All flight schedules and fares displayed on this website are indicative and subject to change without prior notice.
                </p>
                <p>
                  Tickets are issued only after full payment confirmation. We are not directly affiliated with any airline.
                </p>
              </div>
            </section>

            {/* How it works */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <RefreshCcw className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">How Our Service Works</h2>
              </div>
              <ol className="list-decimal list-inside space-y-3 text-slate-600 font-medium">
                <li>Customer searches or requests flight details.</li>
                <li>Travel Assist provides available flight options based on the request.</li>
                <li>Customer confirms passenger details.</li>
                <li>A secure payment link is shared with the customer.</li>
                <li>After payment confirmation, the ticket is issued through airline or authorized booking systems.</li>
              </ol>
            </section>

            {/* International Airline Baggage Policy */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Package className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">International Airline Baggage Policy</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                  <h3 className="font-bold text-slate-900 mb-2">Cabin Baggage Allowances</h3>
                  <p className="mb-4">Standard allowance is usually 1 piece (7kg - 10kg) plus 1 small personal item (laptop bag/handbag). Dimensions typically restricted to 55cm x 40cm x 23cm.</p>
                  
                  <h3 className="font-bold text-slate-900 mb-2">Checked Baggage Allowances</h3>
                  <p className="mb-4">Varies by airline and class. Economy usually allows 20kg - 30kg (Weight Concept) or 1-2 pieces of 23kg each (Piece Concept).</p>
                  
                  <h3 className="font-bold text-slate-900 mb-2">Weight Concept vs Piece Concept</h3>
                  <p className="mb-4"><strong>Weight Concept:</strong> Total weight limit regardless of number of bags. Common in Asia/Europe.<br/><strong>Piece Concept:</strong> Fixed number of bags with a weight limit per bag. Common in Americas/Transatlantic.</p>
                  
                  <h3 className="font-bold text-slate-900 mb-2">Dangerous Goods Restrictions</h3>
                  <p>Items like lithium batteries, flammable liquids, and compressed gases are strictly regulated. Always check with the airline before packing.</p>
                </div>
              </div>
            </section>

            {/* International Airline Pet Policy */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Ship className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">International Airline Pet Policy</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>Major airlines like <strong>Air India, Qatar Airways, Turkish Airlines, Delta, United, Swiss, WestJet, Korean Air,</strong> and <strong>TAP Air Portugal</strong> have specific pet travel rules:</p>
                <ul className="list-disc list-inside space-y-2">
                  <li><strong>Pets Allowed:</strong> Usually dogs, cats, and sometimes birds or rabbits.</li>
                  <li><strong>Cabin vs Cargo:</strong> Small pets (under 8kg incl. carrier) may travel in cabin. Larger pets must travel in the temperature-controlled cargo hold.</li>
                  <li><strong>Carrier Rules:</strong> Must be IATA-compliant, leak-proof, and allow the pet to stand, turn, and lie down comfortably.</li>
                  <li><strong>Reservation:</strong> Must be made at least 48-72 hours in advance as space is limited.</li>
                </ul>
              </div>
            </section>

            {/* Pet Travel Document Requirements */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <CheckCircle className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Pet Travel Document Requirements</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-600">
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Veterinary Health Certificate</span>
                </div>
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Rabies Vaccination Certificate</span>
                </div>
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Vaccination Record</span>
                </div>
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>ISO Microchip Identification</span>
                </div>
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Import/Export Permits</span>
                </div>
                <div className="flex items-center space-x-2 bg-white p-3 rounded-lg border border-slate-100">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Animal Quarantine Clearance</span>
                </div>
              </div>
            </section>

            {/* Terms & Conditions */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <FileText className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Terms & Conditions</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600">
                <p className="mb-4">By using the Travel Assist website or services, you agree to the following terms:</p>
                <ul className="list-disc list-inside space-y-2">
                  <li>All bookings are subject to airline availability and fare rules.</li>
                  <li>Customers are responsible for verifying passenger details including name spelling, passport information, and travel dates before confirming payment.</li>
                  <li>Travel Assist is not responsible for airline schedule changes, delays, cancellations, or operational issues.</li>
                  <li>Service fees charged by Travel Assist are non-refundable once the booking process has started.</li>
                  <li>Airline policies apply for baggage allowance, refunds, cancellations, and rescheduling.</li>
                </ul>
              </div>
            </section>

            {/* Privacy Policy */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Lock className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Privacy Policy</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>Travel Assist respects the privacy of all customers. We may collect personal information such as Name, Email address, Phone number, and Travel details.</p>
                <p>This information is collected only to provide travel assistance and complete bookings.</p>
                <p>Customer information will never be sold or shared with third parties except where required to complete bookings with airlines, travel partners, or payment providers.</p>
              </div>
            </section>

            {/* Refund & Cancellation */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <RefreshCcw className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Refund & Cancellation Policy</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>All flight tickets are governed by the refund and cancellation policies of the respective airline.</p>
                <p>Travel Assist service fees are non-refundable once a booking request has been processed.</p>
                <p>If a customer requests cancellation, refund eligibility will depend entirely on the airline’s fare rules.</p>
                <p>Refund processing time may vary depending on the airline’s systems and policies.</p>
              </div>
            </section>

            {/* Payment Security */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Payment Security</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>Payments are processed through secure and trusted payment gateway providers. Accepted payment methods may include Visa, Mastercard, American Express, Discover, UPI, Debit Cards, Credit Cards, and Net Banking.</p>
                <p>Travel Assist does not store customer credit or debit card details. All transactions are encrypted and processed through secure payment gateways.</p>
              </div>
            </section>

            {/* Fare Disclaimer */}
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <AlertCircle className="w-6 h-6 text-blue-600" />
                <h2 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Fare & Price Disclaimer</h2>
              </div>
              <div className="prose prose-slate max-w-none text-slate-600 space-y-4">
                <p>Airfares and flight schedules shown on this website are for informational purposes only and are indicative. They may change without prior notice due to airline pricing updates, seat availability, or taxes.</p>
                <p>Tickets are issued only after full payment confirmation. We are not directly affiliated with any airline.</p>
              </div>
            </section>

            {/* Additional Sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 mb-2">Third-Party Services</h3>
                <p className="text-sm text-slate-600">Travel Assist may use services provided by airlines, travel consolidators, or payment gateways. We are not responsible for their policies or operational decisions.</p>
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-2">Travel Document Responsibility</h3>
                <p className="text-sm text-slate-600">Passengers are responsible for ensuring they possess valid passports, visas, and other entry requirements. We are not responsible for denied entry.</p>
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-2">Cookies Policy</h3>
                <p className="text-sm text-slate-600">Our website may use cookies to improve user experience. Users may disable cookies in their browser settings if they choose.</p>
              </div>
              <div>
                <h3 className="font-bold text-slate-900 mb-2">Anti-Fraud & Verification</h3>
                <p className="text-sm text-slate-600">We may verify booking information to prevent fraud. Customers may be asked to confirm identity before ticket issuance.</p>
              </div>
            </div>

            <div className="bg-blue-50 rounded-xl p-6 border border-blue-100 mt-10">
              <h3 className="font-bold text-blue-900 mb-4">Limitation of Liability</h3>
              <p className="text-sm text-blue-800">
                Travel Assist shall not be held liable for any indirect loss, travel disruption, or damages resulting from airline delays, cancellations, schedule changes, or force-majeure events beyond our control.
              </p>
            </div>

            <div className="text-center pt-10 border-t border-slate-100">
              <p className="text-sm text-slate-500 mb-2">&copy; 2026 Travel Assist. All Rights Reserved.</p>
              <p className="text-xs text-slate-400 italic mb-4">All website content, text, design, and materials are the intellectual property of Travel Assist and may not be copied or reproduced without permission.</p>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 max-w-2xl mx-auto">
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Independent Service Provider</p>
                <p className="text-xs text-slate-400 mt-1">Travel Assist operates as an independent travel service provider. All airline policies, including baggage, pets, and refunds, are controlled and enforced by the respective airlines.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
