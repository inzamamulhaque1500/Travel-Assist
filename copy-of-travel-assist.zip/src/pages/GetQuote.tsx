import React, { useState } from 'react';
import { Calendar, Users, Phone, Send } from 'lucide-react';
import AirportInput from '../components/AirportInput';

export default function GetQuote() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [date, setDate] = useState('');
  const [passengers, setPassengers] = useState('1');
  const [phone, setPhone] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const message = `*New Quote Request*
*From:* ${from}
*To:* ${to}
*Date:* ${date}
*Passengers:* ${passengers}
*Phone:* ${phone}`;

    try {
      await fetch("https://formsubmit.co/ajax/travelassisthelp1@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          _subject: "New Quote Request - Travel Assist",
          message: message,
          phone: phone
        })
      });
    } catch (error) {
      console.error("Error submitting form", error);
    }

    setIsSubmitting(false);
    setIsSuccess(true);
  };

  if (isSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <Send className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Quote Request Sent!</h2>
        <p className="text-lg text-slate-600 mb-8">
          Your request has been submitted to a travel expert. They will contact you soon with the best possible flight options.
        </p>
        <button 
          onClick={() => setIsSuccess(false)}
          className="text-blue-600 hover:text-blue-800 font-medium underline"
        >
          Submit another request
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-12 min-h-[calc(100vh-4rem)]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Get the Best Flight Deal</h1>
          <p className="text-lg text-slate-600">
            Can't find what you're looking for? Let our experts find the cheapest and most convenient flights for you.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
          <div className="bg-blue-600 p-6 text-white text-center">
            <p className="font-medium">Directly sent to our expert team at</p>
            <a href="mailto:travelassisthelp1@gmail.com" className="text-xl font-bold hover:underline">travelassisthelp1@gmail.com</a>
          </div>
          
          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">From</label>
                <AirportInput value={from} onChange={setFrom} placeholder="Departure City or Airport" type="from" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">To</label>
                <AirportInput value={to} onChange={setTo} placeholder="Destination City or Airport" type="to" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Departure Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input 
                    type="date" 
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Passengers</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <select 
                    value={passengers}
                    onChange={(e) => setPassengers(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all appearance-none"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                      <option key={num} value={num}>{num} {num === 1 ? 'Passenger' : 'Passengers'}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Your Phone Number *</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input 
                  type="tel" 
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="We will contact you with the quote"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-4 px-6 rounded-xl transition-colors shadow-md text-lg mt-4"
            >
              {isSubmitting ? 'Sending Request...' : 'Get Best Deal'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
