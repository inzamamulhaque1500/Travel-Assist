import React, { useState } from 'react';
import { AIRLINES } from '../data/airlines';
import { AIRPORTS } from '../data/airports';
import { COUNTRIES } from '../data/countries';
import { Search, Plane, MapPin, Phone } from 'lucide-react';

export default function AviationData() {
  const [activeTab, setActiveTab] = useState('airlines');
  const [search, setSearch] = useState('');

  const filteredAirlines = AIRLINES.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.iata.toLowerCase().includes(search.toLowerCase()) ||
    a.country.toLowerCase().includes(search.toLowerCase())
  );

  const filteredAirports = AIRPORTS.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.city.toLowerCase().includes(search.toLowerCase()) ||
    a.iata.toLowerCase().includes(search.toLowerCase()) ||
    a.country.toLowerCase().includes(search.toLowerCase())
  );

  const filteredCountries = COUNTRIES.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.dialCode.includes(search)
  );

  return (
    <div className="bg-slate-50 min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-6xl font-black text-slate-900 uppercase tracking-tighter mb-4">Global Aviation Database</h1>
          <p className="text-slate-600 max-w-2xl mx-auto font-medium">Complete aviation dataset following IATA and ICAO standards for the global airline industry.</p>
        </div>

        {/* Search and Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button 
                onClick={() => setActiveTab('airlines')}
                className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === 'airlines' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Airlines
              </button>
              <button 
                onClick={() => setActiveTab('airports')}
                className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === 'airports' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Airports
              </button>
              <button 
                onClick={() => setActiveTab('countries')}
                className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${activeTab === 'countries' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Dialing Codes
              </button>
            </div>
            <div className="relative flex-grow max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder={`Search ${activeTab}...`}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Data Display */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          {activeTab === 'airlines' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Airline Name</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">IATA</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">ICAO</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Country</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAirlines.map((airline, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <Plane className="w-4 h-4 text-blue-500 mr-3" />
                          <span className="font-bold text-slate-900">{airline.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono font-bold text-blue-600">{airline.iata}</td>
                      <td className="px-6 py-4 font-mono text-slate-500">{airline.icao}</td>
                      <td className="px-6 py-4 text-slate-600">{airline.country}</td>
                      <td className="px-6 py-4">
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-tighter ${
                          airline.type === 'Low Cost' ? 'bg-orange-100 text-orange-600' : 
                          airline.type === 'Charter' ? 'bg-purple-100 text-purple-600' : 
                          'bg-blue-100 text-blue-600'
                        }`}>
                          {airline.type}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'airports' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Airport Name</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">City</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Country</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">IATA</th>
                    <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">ICAO</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAirports.map((airport, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 text-orange-500 mr-3" />
                          <span className="font-bold text-slate-900">{airport.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">{airport.city}</td>
                      <td className="px-6 py-4 text-slate-600">{airport.country}</td>
                      <td className="px-6 py-4 font-mono font-bold text-blue-600">{airport.iata}</td>
                      <td className="px-6 py-4 font-mono text-slate-500">{airport.icao}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'countries' && (
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-0 divide-x divide-y divide-slate-100">
              {filteredCountries.map((country, idx) => (
                <div key={idx} className="p-6 hover:bg-slate-50 transition-colors flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center mr-4 text-slate-400 font-bold text-xs">
                      {country.code}
                    </div>
                    <span className="font-bold text-slate-900">{country.name}</span>
                  </div>
                  <div className="flex items-center text-blue-600 font-black">
                    <Phone className="w-3 h-3 mr-1" />
                    {country.dialCode}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
