import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { Resend } from "resend";
import Razorpay from "razorpay";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config();

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
const razorpayKeyId = process.env.VITE_RAZORPAY_KEY_ID || process.env.RAZORPAY_KEY_ID;
const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;

const razorpay = razorpayKeyId && razorpayKeySecret 
  ? new Razorpay({
      key_id: razorpayKeyId,
      key_secret: razorpayKeySecret,
    })
  : null;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    const apiKey = process.env.RESEND_API_KEY;
    res.json({ 
      status: "ok", 
      emailService: apiKey ? "configured" : "not configured",
      emailKeyPrefix: apiKey ? `${apiKey.substring(0, 5)}...` : null,
      paymentService: razorpay ? "configured" : "not configured",
    });
  });

  app.post("/api/create-order", async (req, res) => {
    if (!razorpay) {
      return res.status(500).json({ error: "Razorpay not configured" });
    }

    const { amount, currency = "INR" } = req.body;

    try {
      const order = await razorpay.orders.create({
        amount: Math.round(amount * 100), // amount in smallest currency unit
        currency,
        receipt: `receipt_${Date.now()}`,
      });
      res.json(order);
    } catch (error) {
      console.error("Razorpay order error:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.post("/api/send-email", async (req, res) => {
    const { to, subject, html } = req.body;

    if (!resend) {
      console.warn("RESEND_API_KEY is not set. Email not sent.");
      return res.status(200).json({ success: true, message: "Mock success (API key missing)" });
    }

    console.log(`Attempting to send email to: ${to} with subject: ${subject}`);

    try {
      const { data, error } = await resend.emails.send({
        from: "Travel Assist <onboarding@resend.dev>",
        to: [to],
        subject: subject,
        html: html,
      });

      if (error) {
        console.error("Resend API error details:", error);
        return res.status(400).json({ 
          success: false, 
          error: error.message || "Resend API error",
          details: error
        });
      }

      console.log("Email sent successfully. ID:", data?.id);
      res.json({ success: true, data });
    } catch (error: any) {
      console.error("Unexpected Email error:", error);
      res.status(500).json({ 
        success: false, 
        error: error.message || "Internal server error",
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
